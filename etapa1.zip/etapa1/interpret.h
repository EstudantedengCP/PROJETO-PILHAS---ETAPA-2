#ifndef INTERPRET_H
#define INTERPRET_H

void interpreter_init();
void interpret(const char* source);

#endif
